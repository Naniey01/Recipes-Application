/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.RecipeApplication.service;


import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Teh Bin Han
 */
public interface UserService {
  
    User saveUser(User user);

    List<User> getAllUser();

    User getUserById(long userid);

    User updateUser(User user, long userid);

    void deleteUser(long userid);

    void deleteUserGUI(long userid);

    User get(long userid);

    void saveUserToDB(String username, String email, String password, String role);
    
    void updateUser(Long userid, String username, String email, String password, String role);
    
    User userAuthentication(String username,String password);
    
    List<User>  searchByUserWithKeyword(String keyword);
    
}
