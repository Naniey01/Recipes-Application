package com.example.RecipeApplication.controller;

import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import com.example.RecipeApplication.service.RecipeService;
import com.example.RecipeApplication.service.UserService;
import java.util.List;
import java.util.Objects;
import javax.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Teh Bin Han
 */
@Controller
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @Autowired
    private UserService userService;

    public RecipeController(RecipeService recipeService, UserService userService) {
        super();
        this.recipeService = recipeService;
        this.userService = userService;
    }

    /*For postman CRUD Process*/
    @PostMapping("/api/recipe")
    public ResponseEntity<Recipe> saveRecipe(@RequestBody Recipe recipe) {
        return new ResponseEntity<>(recipeService.saveRecipe(recipe), HttpStatus.CREATED);
    }

    /*Get all of the recipes in GUI and Postman*/
    @GetMapping("/api/recipe")
    @ResponseBody
    public List<Recipe> getAllRecipe() {
        return recipeService.getAllRecipe();
    }

    @GetMapping("/api/recipe/{recipeID}")
    public ResponseEntity<Recipe> getRecipeById(@PathVariable("recipeID") long recipeID) {
        return new ResponseEntity<Recipe>(recipeService.getRecipeById(recipeID), HttpStatus.OK);
    }

    @PutMapping("/api/recipe/update/{recipeID}")
    public ResponseEntity<Recipe> updateRecipe(@PathVariable("recipeID") long recipeID, @RequestBody Recipe recipe) {
        return new ResponseEntity<Recipe>(recipeService.updateRecipe(recipe, recipeID), HttpStatus.OK);
    }

    @DeleteMapping("/api/recipe/delete/{recipeID}")
    public ResponseEntity<String> deleteRecipe(@PathVariable("recipeID") long recipeID) {
        recipeService.deleteRecipe(recipeID);
        return new ResponseEntity<String>("Recipe deleted successfully!", HttpStatus.OK);
    }

    /*For Navigation Parts*/
    @GetMapping("/ManageRecipe")
    public String getManageRecipe(Model model) {
        model.addAttribute("recipe", recipeService.getAllRecipe());
        return "ManageRecipe.html";
    }

    @GetMapping("/")
    public String redirectLogin() {
        return "Login.html";
    }

    @GetMapping("/index")
    public String redirectFrontPage() {
        return "index.html";
    }

    @GetMapping("/CreateRecipe")
    public String getCreateRecipe() {
        return "CreateRecipe.html";
    }

    @GetMapping("/CreateUser")
    public String getCreateUser() {
        return "CreateUser.html";
    }

    @GetMapping("/UserDashboard")
    public String getUserDashboard() {
        return "UserDashboard.html";
    }

    @GetMapping("/ManageUser")
    public String getManageUser(Model model) {
        model.addAttribute("user", userService.getAllUser());
        return "ManageUser.html";
    }

    @GetMapping("/Logout")
    public String getLogout() {
        return "Login.html";
    }

    @GetMapping("/SignUp")
    public String getSignUp() {
        return "SignUp.html";
    }

    @GetMapping("/UserRecipeList")
    public String getUserRecipeList(Model model) {
        model.addAttribute("recipe", recipeService.getAllRecipe());
        return "UserRecipeList.html";
    }

    @GetMapping("/UserOwnRecipe")
    public String getUserOwnRecipe(Model model, HttpSession session) {
        model.addAttribute("recipe", recipeService.getAllRecipeByUserId((long) session.getAttribute("userId")));
        return "UserOwnRecipe.html";
    }

    @GetMapping("/UserCreateRecipe")
    public String getUserCreateRecipe() {
        return "UserCreateRecipe.html";
    }

    @GetMapping("/AdminOwnRecipe")
    public String getAdminOwnRecipe(Model model, HttpSession session) {
        model.addAttribute("recipe", recipeService.getAllRecipeByUserId((long) session.getAttribute("userId")));
        return "AdminOwnRecipe.html";
    }

    /*-----------------------------------------------------Recipe CRUD Process-----------------------------------------------------*/
 /*Save the Recipe*/
    @PostMapping("/api/recipe/save")
    @ResponseBody
    public RedirectView saveRecipeGUI(HttpSession session,
            @RequestParam(required = false) String creator, @RequestParam(required = false) String title,
            @RequestParam(required = false) MultipartFile image,
            @RequestParam(required = false) String category, @RequestParam(required = false) String estimationTime,
            @RequestParam(required = false) String ingredients, @RequestParam(required = false) String steps,
            @RequestParam(required = false) long userid) {
        if (session.getAttribute("userId") != null) {
            long tempUserId = (long) session.getAttribute("userId");
            if (Objects.equals(tempUserId, userid)) {
                User user = userService.getUserById((long) session.getAttribute("userId"));
                if (user != null) {
                    recipeService.saveToDB(creator, title, image, category, estimationTime, ingredients, steps, user);
                }
                return new RedirectView("/AdminOwnRecipe");
            }
            return new RedirectView("/AdminOwnRecipe");
        }
        return new RedirectView("/AdminOwnRecipe");
    }

    /*Edit the Recipe*/
    @GetMapping("/api/recipe/edit/{recipeID}")
    @ResponseBody
    public ModelAndView getspecificRecipe(@PathVariable("recipeID") long recipeID
    ) {
        ModelAndView editView = new ModelAndView("EditRecipe");
        Recipe recipe = recipeService.getRecipeById(recipeID);
        editView.addObject("recipe", recipe);
        return editView;
    }

    /*Update the Recipe*/
    @PostMapping("/api/recipe/update/{recipeID}")
    public RedirectView showRecipe(@PathVariable("recipeID") long recipeID,
            @RequestParam("creator") String creator, @RequestParam("title") String title,
            @RequestParam("image") MultipartFile image,
            @RequestParam("category") String category, @RequestParam("estimationTime") String estimationTime,
            @RequestParam("ingredients") String ingredients, @RequestParam("steps") String steps,
            @RequestParam("creatorUser") User creatorUser
    ) {

        recipeService.updateRecipe(recipeID, creator, title, image, category, estimationTime, ingredients, steps, creatorUser);

        return new RedirectView("/ManageRecipe");
    }

    /*Delete the Recipe*/
    @GetMapping("/api/recipe/deleteGUI/{recipeID}")
    public RedirectView deleteRecipeGUI(@PathVariable(name = "recipeID") long recipeID
    ) {
        recipeService.deleteRecipe(recipeID);
        return new RedirectView("/ManageRecipe");
    }

    /*View the Recipe that is selected*/
    @GetMapping("/api/recipe/View/{recipeID}")
    public ModelAndView getspecificRecipeById(@PathVariable("recipeID") long recipeID
    ) {
        ModelAndView editView = new ModelAndView("ViewRecipe");
        Recipe recipe = recipeService.getRecipeById(recipeID);
        editView.addObject("recipe", recipe);
        return editView;
    }

    /*These recipe methods are for user*/
    @PostMapping("/api/recipe/user/save")
    @ResponseBody
    public RedirectView saveUserRecipeGUI(HttpSession session,
            @RequestParam(required = false) String creator, @RequestParam(required = false) String title,
            @RequestParam(required = false) MultipartFile image,
            @RequestParam(required = false) String category, @RequestParam(required = false) String estimationTime,
            @RequestParam(required = false) String ingredients, @RequestParam(required = false) String steps,
            @RequestParam(required = false) long userid
    ) {
        if (session.getAttribute("userId") != null) {
            long tempUserId = (long) session.getAttribute("userId");
            if (Objects.equals(tempUserId, userid)) {
                User user = userService.getUserById((long) session.getAttribute("userId"));
                if (user != null) {
                    recipeService.saveToDB(creator, title, image, category, estimationTime, ingredients, steps, user);
                }
                return new RedirectView("/UserOwnRecipe");
            }
            return new RedirectView("/UserOwnRecipe");
        }
        return new RedirectView("/UserOwnRecipe");
    }

    @GetMapping("/api/recipe/user/View/{recipeID}")
    public ModelAndView getUserspecificRecipeById(@PathVariable("recipeID") long recipeID
    ) {
        ModelAndView editView = new ModelAndView("UserViewRecipe");
        Recipe recipe = recipeService.getRecipeById(recipeID);
        editView.addObject("recipe", recipe);
        return editView;
    }

    /*Edit the Recipe*/
    @GetMapping("/api/recipe/user/edit/{recipeID}")
    @ResponseBody
    public ModelAndView editUserRecipe(@PathVariable("recipeID") long recipeID
    ) {
        ModelAndView editView = new ModelAndView("UserEditRecipe");
        Recipe recipe = recipeService.getRecipeById(recipeID);
        editView.addObject("recipe", recipe);
        return editView;
    }

    /*Update the Recipe*/
    @PostMapping("/api/recipe/user/update/{recipeID}")
    public RedirectView updateUserRecipe(@PathVariable("recipeID") long recipeID,
            @RequestParam("creator") String creator, @RequestParam("title") String title,
            @RequestParam("image") MultipartFile image,
            @RequestParam("category") String category, @RequestParam("estimationTime") String estimationTime,
            @RequestParam("ingredients") String ingredients, @RequestParam("steps") String steps,
            @RequestParam("creatorUser") User creatorUser
    ) {

        recipeService.updateRecipe(recipeID, creator, title, image, category, estimationTime, ingredients, steps, creatorUser);

        return new RedirectView("/UserOwnRecipe");
    }

    /*Delete the Recipe*/
    @GetMapping("/api/recipe/user/deleteGUI/{recipeID}")
    public RedirectView deleteUserRecipeGUI(@PathVariable(name = "recipeID") long recipeID
    ) {
        recipeService.deleteRecipe(recipeID);
        return new RedirectView("/UserOwnRecipe");
    }

    /*View the Recipe that is selected*/
    @GetMapping("/api/recipe/user/ViewOwnRecipe/{recipeID}")
    public ModelAndView getspecificIUserRecipeById(@PathVariable("recipeID") long recipeID
    ) {
        ModelAndView editView = new ModelAndView("UserViewOwnRecipe");
        Recipe recipe = recipeService.getRecipeById(recipeID);
        editView.addObject("recipe", recipe);
        return editView;
    }

    @GetMapping("api/recipe/search/list")
    public String searchByKeyword(Model model, @Param("keyword") String keyword
    ) {
//        ModelAndView editView = new ModelAndView("UserRecipeList");
        List<Recipe> recipe = recipeService.searchByKeyword(keyword);
        model.addAttribute("recipe", recipe);
        model.addAttribute("keyword", keyword);
        return "UserRecipeList";
    }

    @GetMapping("api/recipe/search/admin/list")
    public String searchByKeywordAdmin(Model model, @Param("keyword") String keyword
    ) {
//        ModelAndView editView = new ModelAndView("UserRecipeList");
        List<Recipe> recipe = recipeService.searchByKeyword(keyword);
        model.addAttribute("recipe", recipe);
        model.addAttribute("keyword", keyword);
        return "ManageRecipe";
    }


    /*-----------------------------------------------------User CRUD Process-----------------------------------------------------*/
 /*For postman CRUD Process*/
    @PostMapping("/api/save/user")
    public ResponseEntity<User> saveUser(@RequestBody User user
    ) {
        return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
    }

    @PostMapping("/api/user/save")
    @ResponseBody
    public RedirectView saveUserGUI(
            @RequestParam(required = false) String username, @RequestParam(required = false) String email,
            @RequestParam(required = false) String password,
            @RequestParam(required = false) String role
    ) {
        userService.saveUserToDB(username, email, password, role);
        return new RedirectView("/ManageUser");
    }

    @PostMapping("/api/user/signup")
    @ResponseBody
    public RedirectView SignUpUserGUI(
            @RequestParam(required = false) String username, @RequestParam(required = false) String email,
            @RequestParam(required = false) String password,
            @RequestParam(required = false) String role
    ) {
        userService.saveUserToDB(username, email, password, role);
        return new RedirectView("/");
    }

    /*Get all of the recipes in GUI and Postman*/
    @GetMapping("/api/user")
    @ResponseBody
    public List<User> getAllUser() {
        return userService.getAllUser();
    }

    @GetMapping("/api/user/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable("userId") long userid
    ) {
        return new ResponseEntity<User>(userService.getUserById(userid), HttpStatus.OK);
    }

    @PutMapping("/api/user/update/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable("userId") long userid, @RequestBody User user
    ) {
        return new ResponseEntity<User>(userService.updateUser(user, userid), HttpStatus.OK);
    }

    @DeleteMapping("/api/user/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable("userId") long userid
    ) {
        userService.deleteUser(userid);
        return new ResponseEntity<String>("User deleted successfully!", HttpStatus.OK);
    }

    /*For interface CRUD user only, not for postman*/
 /*Edit the User Info*/
    @GetMapping("/api/user/edit/{userId}")
    @ResponseBody
    public ModelAndView getspecificUser(@PathVariable("userId") long userid
    ) {
        ModelAndView editView = new ModelAndView("EditUser");
        User user = userService.getUserById(userid);
        editView.addObject("user", user);
        return editView;
    }

    /*Update the User Info*/
    @PostMapping("/api/user/update/{userId}")
    public RedirectView showUser(@PathVariable("userId") long userid,
            @RequestParam("username") String username,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("role") String role
    ) {

        userService.updateUser(userid, username, email, password, role);

        return new RedirectView("/ManageUser");
    }

    /*Delete the User Info*/
    @GetMapping("/api/user/deleteGUI/{userId}")
    public RedirectView deleteUserGUI(@PathVariable(name = "userId") long userid
    ) {
        userService.deleteUser(userid);
        return new RedirectView("/ManageUser");
    }

    @GetMapping("api/recipe/search/user/list")
    public String searchByUserWithKeyword(Model model, @Param("keyword") String keyword
    ) {
//        ModelAndView editView = new ModelAndView("UserRecipeList");
        List<User> user = userService.searchByUserWithKeyword(keyword);
        model.addAttribute("user", user);
        model.addAttribute("keyword", keyword);
        return "ManageUser";
    }

    /*Login*/
    @PostMapping("/processLogin")
    public String processLogin(@RequestParam("username") String username, @RequestParam("password") String password, HttpSession session
    ) {
        User loginUser = userService.userAuthentication(username, password);
        System.out.print(loginUser);
        if (loginUser != null) {
            session.setAttribute("username", username);
            session.setAttribute("email", loginUser.getEmail());
            session.setAttribute("role", loginUser.getRole());
            session.setAttribute("userId", loginUser.getUserid());
            if (loginUser.getRole().equals("A")) {
                return ("redirect:/index");
            } else {
                return ("redirect:/UserDashboard");
            }
        } else {
            return ("redirect:/");
        }
    }

    /*Logout*/
    @RequestMapping("/Logout")
    public String logout(HttpSession session
    ) {
        session.removeAttribute("username");
        session.removeAttribute("email");
        session.removeAttribute("role");
        session.removeAttribute("userId");
        return ("redirect:/");
    }
}
