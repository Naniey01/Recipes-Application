/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.RecipeApplication.service.impl;

import com.example.RecipeApplication.exception.ResourceNotFoundException;
import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import com.example.RecipeApplication.repository.RecipeRepository;

import com.example.RecipeApplication.service.RecipeService;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Teh Bin Han
 */
@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

    public RecipeServiceImpl(RecipeRepository recipeRepository) {
        super();
        this.recipeRepository = recipeRepository;
    }

    @Override
    public Recipe saveRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    @Override
    public void saveToDB(String creator, String title, MultipartFile image, String category, String estimationTime, String ingredients, String steps, User creatorUser) {

        Recipe recipe = new Recipe();

        String fileName = StringUtils.cleanPath(image.getOriginalFilename());
        if (fileName.contains("..")) {
            System.out.println("not a valid file");
        }

        if (fileName != null) {
            try {
                recipe.setCreator(creator);
                recipe.setTitle(title);
                recipe.setCategory(category);
                recipe.setImage(Base64.getEncoder().encodeToString(image.getBytes()));
                recipe.setEstimationTime(estimationTime);
                recipe.setIngredients(ingredients);
                recipe.setSteps(steps);
                recipe.setCreatorUser(creatorUser);
                recipeRepository.save(recipe);
            } catch (IOException ex) {
                Logger.getLogger(RecipeServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            recipe.setCreator(creator);
            recipe.setTitle(title);
            recipe.setCategory(category);
            recipe.setImage("");
            recipe.setEstimationTime(estimationTime);
            recipe.setIngredients(ingredients);
            recipe.setSteps(steps);
            recipe.setCreatorUser(creatorUser);
            recipeRepository.save(recipe);
        }
    }

    @Override
    public void updateRecipe(Long recipeid, String creator, String title, MultipartFile image, String category, String estimationTime, String ingredients, String steps, User creatorUser) {
        Recipe recipe = recipeRepository.getById(recipeid);
        String fileName = StringUtils.cleanPath(image.getOriginalFilename());
        if (fileName.contains("..") || image.isEmpty()) {
            recipe.setCreator(creator);
            recipe.setTitle(title);
            recipe.setCategory(category);
            recipe.setEstimationTime(estimationTime);
            recipe.setIngredients(ingredients);
            recipe.setSteps(steps);
            recipe.setCreatorUser(creatorUser);
            recipeRepository.save(recipe);
        } else {
            try {
                recipe.setImage(Base64.getEncoder().encodeToString(image.getBytes()));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            recipe.setCreator(creator);
            recipe.setTitle(title);
            recipe.setCategory(category);
            recipe.setEstimationTime(estimationTime);
            recipe.setIngredients(ingredients);
            recipe.setSteps(steps);
            recipe.setCreatorUser(creatorUser);
            recipeRepository.save(recipe);
        }
    }

    @Override
    public List<Recipe> getAllRecipe() {
        return recipeRepository.findAll();
    }

    @Override
    public Recipe getRecipeById(long recipeID) {
        Optional<Recipe> recipe = recipeRepository.findById(recipeID);

        if (recipe.isPresent()) {
            return recipe.get();
        } else {
            throw new ResourceNotFoundException("Recipe", "Recipe ID", recipeID);
        }
//        return recipeRepository.findById(recipeID).orElseThrow(() -> new ResourceNotFoundException("Recipe", "Recipe ID", recipeID));
    }

    @Override
    public Recipe updateRecipe(Recipe recipe, long recipeID) {
        Recipe existingRecipe = recipeRepository.findById(recipeID).orElseThrow(() -> new ResourceNotFoundException("Recipe", "Recipe ID", recipeID));
        existingRecipe.setCreator(recipe.getCreator());
        existingRecipe.setIngredients(recipe.getIngredients());
        existingRecipe.setSteps(recipe.getSteps());
        recipeRepository.save(existingRecipe);
        return existingRecipe;
    }

    @Override
    public void deleteRecipe(long recipeid) {
        recipeRepository.findById(recipeid).orElseThrow(() -> new ResourceNotFoundException("Recipe", "Recipe ID", recipeid));
        recipeRepository.deleteById(recipeid);
    }

    @Override
    public void deleteRecipeGUI(long recipeid) {
        recipeRepository.findById(recipeid).orElseThrow(() -> new ResourceNotFoundException("Recipe", "Recipe ID", recipeid));
        recipeRepository.deleteById(recipeid);
    }

    @Override
    public Recipe get(long recipeid) {
        return recipeRepository.findById(recipeid).get();
    }

    @Override
    public List<Recipe> getAllRecipeByUserId(long userid) {
        return recipeRepository.findAllByUserId(userid);
    }
    
    @Override
    public List<Recipe> searchByKeyword(String keyword) {
        return recipeRepository.searchByKeyword(keyword);
    }
    
    @Override
    public List<Recipe> searchByKeywordAdmin(String keyword) {
        return recipeRepository.searchByKeyword(keyword);
    }

    

}
