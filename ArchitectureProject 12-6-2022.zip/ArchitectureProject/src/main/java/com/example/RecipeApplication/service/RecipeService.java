/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.RecipeApplication.service;

import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Teh Bin Han
 */
public interface RecipeService {

    Recipe saveRecipe(Recipe recipe);

    List<Recipe> getAllRecipe();

    Recipe getRecipeById(long recipeid);

    Recipe updateRecipe(Recipe recipe, long recipeid);

    void deleteRecipe(long recipeid);

    void deleteRecipeGUI(long recipeid);

    Recipe get(long recipeid);
    
    List<Recipe> getAllRecipeByUserId(long userid);
    
    List<Recipe> searchByKeyword(String keyword);
    
    List<Recipe> searchByKeywordAdmin(String keyword);

    void saveToDB(String creator, String title, MultipartFile image, String category, String estimationTime, String ingredients, String steps, User creatorUser);

    void updateRecipe(Long recipeid, String creator, String title, MultipartFile image, String category, String estimationTime, String ingredients, String steps, User creatorUser);
}
