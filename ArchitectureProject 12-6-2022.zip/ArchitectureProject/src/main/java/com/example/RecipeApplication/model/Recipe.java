/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.RecipeApplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import org.springframework.lang.Nullable;

@Data
@Entity
@Table(name = "recipe")
public class Recipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recipeid", nullable = false)
    private long recipeid;

    @Column(name = "creator", nullable = false)
    private String creator;

    @Column(name = "title", nullable = false)
    private String title;

    @Nullable
    @Column(name = "image", columnDefinition = "MEDIUMBLOB")
    private String image;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "estimationTime", nullable = false)
    private String estimationTime;

    @Column(name = "ingredients", nullable = false)
    private String ingredients;

    @Column(name = "steps", nullable = false)
    private String steps;

    @ManyToOne(optional = false)
    @JoinColumn(name = "userid", referencedColumnName = "userid", nullable = false)
    private User creatorUser;

    public Recipe() {
    }

    /*These constructors, getters, and setters are not neccessary, this is because we are using lombok annotation (@Data).*/
    public Recipe(int recipeid, String creator, String title, String image, String category, String estimationTime, String ingredients, String steps) {
        this.recipeid = recipeid;
        this.creator = creator;
        this.title = title;
        this.image = image;
        this.category = category;
        this.estimationTime = estimationTime;
        this.ingredients = ingredients;
        this.steps = steps;
    }

    public Recipe(String creator, String title, String category, String image, String estimationTime, String ingredients, String steps) {
        this.creator = creator;
        this.title = title;
        this.image = image;
        this.category = category;
        this.estimationTime = estimationTime;
        this.ingredients = ingredients;
        this.steps = steps;
    }

    public long getRecipeID() {
        return recipeid;
    }

    public void setRecipeID(long recipeid) {
        this.recipeid = recipeid;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEstimationTime() {
        return estimationTime;
    }

    public void setEstimationTime(String estimationTime) {
        this.estimationTime = estimationTime;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }

    public long getRecipeid() {
        return recipeid;
    }

    public void setRecipeid(long recipeid) {
        this.recipeid = recipeid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public User getCreatorUser() {
        return creatorUser;
    }

    public void setCreatorUser(User creatorUser) {
        this.creatorUser = creatorUser;
    }

    @Override
    public String toString() {
        return "Recipe{" + "Recipe ID=" + recipeid + ", Creator=" + creator + ", Ingredients" + ingredients + ", Steps=" + steps + "}";
    }

}
