/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.RecipeApplication.repository;

import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Teh Bin Han
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    User getByUsernameAndPassword(String username, String password);

    @Query("SELECT user FROM User user WHERE CONCAT(user.username, user.email, user.role) LIKE %?1%")
    List<User> searchByUserWithKeyword(String keyword);
}
