/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.RecipeApplication.repository;

import com.example.RecipeApplication.model.Recipe;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Teh Bin Han
 */
@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Long> {

    @Query("SELECT recipe FROM Recipe recipe WHERE recipe.creatorUser.userid=?1")
    List<Recipe> findAllByUserId(long userid);

    @Query("SELECT recipe FROM Recipe recipe WHERE CONCAT(recipe.creator, recipe,title, recipe.category, recipe.ingredients) LIKE %?1%")
    List<Recipe> searchByKeyword(String keyword);

    @Query("SELECT recipe FROM Recipe recipe WHERE CONCAT(recipe.recipeid, recipe.creator, recipe,title, recipe.category, recipe.ingredients) LIKE %?1%")
    List<Recipe> searchByKeywordAdmin(String keyword);

}
