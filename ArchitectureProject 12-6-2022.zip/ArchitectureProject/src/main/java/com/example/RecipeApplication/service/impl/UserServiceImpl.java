/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.RecipeApplication.service.impl;

import com.example.RecipeApplication.exception.ResourceNotFoundException;
import com.example.RecipeApplication.model.Recipe;
import com.example.RecipeApplication.model.User;
import com.example.RecipeApplication.repository.UserRepository;
import com.example.RecipeApplication.service.UserService;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Teh Bin Han
 */
@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(long userId) {
        Optional<User> user = userRepository.findById(userId);

        if (user.isPresent()) {
            return user.get();
        } else {
            throw new ResourceNotFoundException("User", "User ID", userId);
        }
    }

    @Override
    public User updateUser(User user, long userId) {
        User existingUser = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "User ID", userId));
        existingUser.setUsername(user.getUsername());
        existingUser.setEmail(user.getEmail());
        existingUser.setPassword(user.getPassword());
        existingUser.setRole(user.getRole());
        userRepository.save(existingUser);
        return existingUser;
    }

    @Override
    public void deleteUser(long userId) {
        userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "User ID", userId));
        userRepository.deleteById(userId);
    }

    @Override
    public void saveUserToDB(String username, String email, String password, String role) {

        User user = new User();

        if (email.contains("@gmail.com") || email.contains("@hotmail.com") || email.contains("@yahoo.com")) {
            user.setUsername(username);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole(role);
            userRepository.save(user);
        } else {
            System.out.println("Not a valid email");
        }

    }

//        recipe.setCreator(creator);
//        recipe.setTitle(title);
//        recipe.setCategory(category);
//        recipe.setEstimationTime(estimationTime);
//        recipe.setIngredients(ingredients);
//        recipe.setSteps(steps);
//        recipeRepository.save(recipe);
    @Override
    public void updateUser(Long userid, String username, String email, String password, String role) {
        User user = userRepository.getById(userid);
        String ValidEmail = user.getEmail();
        if (!ValidEmail.contains("@gmail.com") || !ValidEmail.contains("@hotmail.com") || !ValidEmail.contains("@yahoo.com")) {
            System.out.println("not a valid email");
            user.setUsername(username);
            user.setPassword(password);
            user.setRole(role);
            userRepository.save(user);
        } else {

            user.setUsername(username);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole(role);
            userRepository.save(user);
        }
    }

    @Override
    public void deleteUserGUI(long userid) {
        userRepository.findById(userid).orElseThrow(() -> new ResourceNotFoundException("User", "User ID", userid));
        userRepository.deleteById(userid);
    }

    @Override
    public User get(long userid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public User userAuthentication(String username, String password) {
        User user = userRepository.getByUsernameAndPassword(username, password);
//        if (user != null) {
//        if (user.getUsername().equals(username) || user.getPassword().equals(password)) {
        return user;
//            } else {
//                return null;
//
//            }
//        } else {
//            return null;
//        }
//        }
    }

    @Override
    public List<User>  searchByUserWithKeyword(String keyword) {
        return userRepository.searchByUserWithKeyword(keyword);
    }

}
