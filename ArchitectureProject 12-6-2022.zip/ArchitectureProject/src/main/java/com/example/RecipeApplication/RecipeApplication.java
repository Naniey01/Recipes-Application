package com.example.RecipeApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

//@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class },
@SpringBootApplication(scanBasePackages= {"com.example.RecipeApplication.model","com.example.RecipeApplication.service","com.example.RecipeApplication.controller", "com.example.RecipeApplication.servie.impl"})
@EnableJpaRepositories("com.example.RecipeApplication.repository")
@ComponentScan({"com.example.RecipeApplication.model","com.example.RecipeApplication.service","com.example.RecipeApplication.controller", "com.example.RecipeApplication.service.impl"})
public class RecipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeApplication.class, args);
	}

}
